/*
 * Esha Shah
 * CSE 4344 - Computer Networks
 * Professor Yonghe Liu
 * Lab 1:
 * references:
 * https://www.cs.helsinki.fi/u/jakangas/Teaching/CBU/lab1.html
 * https://www.ccs.neu.edu/home/rraj/Courses/U640/F04/Programs/WebServer.java
 * http://javarevisited.blogspot.com/2015/09/how-to-read-file-into-string-in-java-7.html
 * https://howtodoinjava.com/java/io/java-read-file-to-string-examples/
 */

package network;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.nio.file.Files;

public class socketHandler implements Runnable{
    Socket uSock;
    
    socketHandler(Socket mySock){uSock=mySock;}
    //sets up a thread
    public void run(){
        try{
            req(uSock);
            return ;
        }
        catch (IOException e){
            System.out.println(e);
        }
    }
    //parse the request 
    private void req(Socket usock) throws IOException{
                //stream input from the port
                BufferedReader inputStream = new BufferedReader(new InputStreamReader(usock.getInputStream()));
                String line;
                String req;
                while ((line = inputStream.readLine())!= null){
                    if(line.length()==0){
                        break;
                    }
                    if(line.contains("GET")){
                        req = line.substring(4, line.length()-9);
                        System.out.println("Request after being parsed: "+ req);
                        
                        respond(usock, req);
                    }
                    System.out.println(line);
                }
                System.out.println();
                usock.close();
                inputStream.close();
            }
    //parsing the HTTP request
    private void respond(Socket usock, String req){
        try{
        PrintWriter responseStream = new PrintWriter(usock.getOutputStream());
        
        //print the headers according to the request
        switch(req){
        
            // respond with the web page and a 200
            case "/index.html": responseStream.print("HTTP/1.1 200 OK \r\n");
                                responseStream.print("Content-Type: text/html\r\n"); // The type of data
                                responseStream.print("Connection: close\r\n"); // Will close stream
                                responseStream.print("\r\n"); // End of header
                                String indexFile = textReader("index.html");
                                responseStream.print(indexFile);
                                responseStream.close();
                                break;
                                
            //open the image and a 200
            case "/landscape.jpg": responseStream.print("HTTP/1.1 200 OK \r\n");
                                responseStream.print("Content-Type: image/jpg\r\n"); 
                                responseStream.print("Content-Length: 80110\r\n");
                                
                                //close the connection
                                responseStream.print("Connection: close\r\n"); 
                                responseStream.print("\r\n"); 
                                
                                URL url = getClass().getResource("landscape.jpg");
                                File file = new File(url.getPath());
                                Files.copy(file.toPath(), usock.getOutputStream());
                                responseStream.close();
                                break;    
                                
            //to throw a 304                   
            case "/":           responseStream.print("HTTP/1.1 301 Moved Permanently \r\n");
                                responseStream.print("Content-Type: text/html\r\n");
                                responseStream.print("Location: /index.html\r\n");
                                responseStream.print("Connection: close\r\n"); 
                                responseStream.print("\r\n"); 
                                responseStream.close();
                                break;
                                
            //in any other case when not found, throw a HTTP 404                  
            default:            responseStream.print("HTTP/1.1 404 Not Found \r\n");
                                responseStream.print("Content-Type: text/html\r\n"); 
                                responseStream.print("Connection: close\r\n"); 
                                responseStream.print("\r\n"); 
                                responseStream.close();
                                break;
        }
        
        }
        catch(Exception error){
            System.err.print("There is an error: ");
            System.err.println(error);
        }
    }

    private String textReader(String fileName) throws IOException {
        InputStream fileStream = getClass().getResourceAsStream(fileName);
        BufferedReader fileLines = new BufferedReader(new InputStreamReader(fileStream));
        String line = fileLines.readLine();
        StringBuilder sb = new StringBuilder();
        
        while(line != null){
            sb.append(line).append("\n");
            line = fileLines.readLine();
        }
        String fullFile = sb.toString();
        return fullFile;
    }
    
}
