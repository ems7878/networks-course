/*
 * Esha Shah
 * CSE 4344 - Computer Networks
 * Professor Yonghe Liu
 * Lab 1:
 * references:
 * https://www.cs.helsinki.fi/u/jakangas/Teaching/CBU/lab1.html
 * https://www.ccs.neu.edu/home/rraj/Courses/U640/F04/Programs/WebServer.java
 * http://javarevisited.blogspot.com/2015/09/how-to-read-file-into-string-in-java-7.html
 * https://howtodoinjava.com/java/io/java-read-file-to-string-examples/
 */

package network;

public class Network {

	//server listens for a new listing on port 6789
    public static void main(String args[]) {
        Thread listing = new Thread(new webServer(6789));
        listing.start();
    } 
    
}
