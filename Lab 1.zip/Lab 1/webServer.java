/*
 * Esha Shah
 * CSE 4344 - Computer Networks
 * Professor Yonghe Liu
 * Lab 1:
 * references:
 * https://www.cs.helsinki.fi/u/jakangas/Teaching/CBU/lab1.html
 * https://www.ccs.neu.edu/home/rraj/Courses/U640/F04/Programs/WebServer.java
 * http://javarevisited.blogspot.com/2015/09/how-to-read-file-into-string-in-java-7.html
 * https://howtodoinjava.com/java/io/java-read-file-to-string-examples/
 */

package network;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class webServer implements Runnable{
    private ServerSocket socket;
    private Socket usock;
    private int port;
    webServer(int iport){
    	port = iport;
    	}
    
    public void run(){
        try{                
            listen();
        }
        catch (Exception e){
            System.out.println(e);
        }
    }
    
    //Displays the request after waiting for it
    public void listen(){        
        try {
            // new port
            socket = new ServerSocket(port);
           // waits for a connection request
            System.out.println("Waiting for a connection...");
            waitCon();
            socket.close();
        } 
        catch (IOException ex) {
            System.out.println(ex);
        }
        
    }
    
    //this method waits for the connection
    private void waitCon() throws IOException{
        while(true){
                //Set up the socket 
                usock = socket.accept();
                Thread handle = new Thread(new socketHandler(usock));
                // accept the connection
                handle.start();
        }           
    }
    
}
