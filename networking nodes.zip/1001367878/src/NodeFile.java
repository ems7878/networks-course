/*
 * Esha Shah
 * cse 4344 lab 2
 * 1001367878
 */
import java.util.Collections;
import java.util.TreeMap;
import java.util.TreeSet;

public class NodeFile {
	public static final int infinitycost = 16;
	
	public int ID;
	public TreeMap<Integer, TreeMap<Integer, Integer>> distVectTable; 
	public TreeMap<Integer, Integer> routingTable;
	public boolean isItUnsent;
	public boolean rcvdMsgNew;
	
//creating the distance vector table along with the routing table
	public NodeFile(int ID, TreeSet<Integer> ids) {
		this.ID = ID;
		
		distVectTable = new TreeMap<Integer, TreeMap<Integer, Integer>>();
		routingTable = new TreeMap<Integer, Integer>();

		distVectTable.put(ID, new TreeMap<Integer, Integer>());

		for(int id : ids) {
			if(id == this.ID) {
				distVectTable.get(this.ID).put(id, 0);
				routingTable.put(this.ID, this.ID);
			} else {
				distVectTable.get(this.ID).put(id, infinitycost);
				routingTable.put(id, infinitycost);
			}
		}
		
		isItUnsent = true;
		rcvdMsgNew = false;
	}
	
	//Bellman-Ford algorithm
	public void computeTable() {
		for(int destinationID : distVectTable.get(this.ID).keySet()) {
			TreeMap<Integer, Integer> neighborDistances = new TreeMap<Integer, Integer>();
			for(int neighborID : distVectTable.keySet()) {
				int thisToNeighbor = distVectTable.get(this.ID).get(neighborID);
				int neighborToDestination = distVectTable.get(neighborID).get(destinationID);
				neighborDistances.put(thisToNeighbor + neighborToDestination, neighborID);
			}
			
			int leastCost = Collections.min(neighborDistances.keySet());
			int oldLeastCost = distVectTable.get(this.ID).get(destinationID);
			if(leastCost < oldLeastCost) {
				isItUnsent = true;
				distVectTable.get(this.ID).put(destinationID, leastCost);
			}
		}
		//this makes sure that the node has handled the incoming message
		rcvdMsgNew = false; 
	}
	
	//to check if the node has received a new message
	public void receiveMessage(int senderID, TreeMap<Integer, Integer> tableEntry) {
		rcvdMsgNew = true;
		
		distVectTable.put(senderID, (TreeMap<Integer, Integer>) tableEntry.clone()); 
	
	}
	
	//this displays the table
	public String toString() {
		String result = "";
		result += "Node " + this.ID + "\n\n";
		result += " ";
		for(int destinationID : distVectTable.get(this.ID).keySet()) {
			result += String.format("  %3d", destinationID);
		}
		result += "\n";

		for(int originID : distVectTable.keySet()) {
			result += originID + "   ";
			for(int destinationID : distVectTable.get(originID).keySet()) {
				result += String.format("%2d   ", distVectTable.get(originID).get(destinationID));
			}
			result += "\n";
		}
		
		return result;
	}
	
	//this is to add in a new neighbouring node
	public void addNeighbor(int neighborID, int distance, TreeSet<Integer> ids) {

		distVectTable.put(neighborID, new TreeMap<Integer, Integer>());

		for(int id : ids) {
			if(id == neighborID) {
				distVectTable.get(neighborID).put(id, 0);
			} else {
				distVectTable.get(neighborID).put(id, infinitycost);
			}
		}
		
		distVectTable.get(this.ID).put(neighborID, distance);

	}
	//set cost for neighboring links
	public void setLink(int neighborID, int cost) {
		distVectTable.get(this.ID).put(neighborID, cost);
		isItUnsent = true;
	}
}
