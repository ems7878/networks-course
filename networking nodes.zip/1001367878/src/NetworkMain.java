/*
 * Esha Shah
 * cse 4344 lab 2
 * 1001367878
 */
import java.io.IOException;
import java.util.Scanner;

public class NetworkMain {
	public static final int infinitycost = 16; // defining infinity
	public static void main(String[] args) {
		boolean wasTimed = false;
		int timingDiff;
		
		try {
			String userInput = "";
			Scanner reader = new Scanner(System.in); //taking in user userInput
			
			System.out.print("Enter file (with extension): ");
			userInput = reader.nextLine(); 
			Network net = new Network(userInput);
			

			do {
				clearScreen();
				System.out.println(net);
				if(net.networkStability()) {
					System.out.print("\nThe stable state was reached at  " + net.time );
					if(wasTimed) {
						System.out.println(" clock cycles (time) after function beStable started");
						wasTimed = false;
					}
				}
				
				//displays the options
				System.out.print("\n Enter the following number to:- \n "
						+ "1. Show next step \n 2. Stabilize  \n 3. Change cost of link  \n 4. Exit  \n\nHere: ");
				userInput = reader.nextLine();
				
				//in order to show the next step
				if(userInput.equals("1") && !net.networkStability()) {
					net.recomputeRouting();
				} 
				
				//this is to make system in steady state and computes the time elapsed in clock cycles
				else if(userInput.equals("2") && !net.networkStability()) {
					int start = net.time;
					net.beStable();
					int end = net.time;
					timingDiff = end - start;
					wasTimed = true;
				} 
				
				//changes the cost of the link
				else if(userInput.equals("3")) {
					System.out.print("Enter node 1, node 2 and the nodal cost: ");
					userInput = reader.nextLine();
					String data[] = userInput.split(" ");
					int nodeone = Integer.parseInt(data[0]);
					int nodetwo = Integer.parseInt(data[1]);
					int nodalcost = Integer.parseInt(data[2]);
					
					net.changeLink(nodeone, nodetwo, nodalcost);
				}
			} 
			// exits the program
			while(!userInput.equals("4")) ;
		
			reader.close(); 
			System.out.println("\nGoodbye.\n");
		} catch(Exception e) {
			System.err.println(e);
		}
		
	}
	
	//to clean up the display
	private static void clearScreen() throws IOException {
		System.out.print("\n\n");
	}
}
