/*
 * Esha Shah
 * cse 4344 lab 2
 * https://algs4.cs.princeton.edu/44sp/BellmanFordSP.java.html
 * https://www.geeksforgeeks.org/3-different-ways-print-exception-messages-java/
 * https://faculty.washington.edu/moishe/javademos/javadocs/LoadFromFile.html
 * 1001367878
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.TreeMap;
import java.util.TreeSet;

public class Network {
	public static final int infinitycost = 16;
	
	public TreeSet<Integer> nodeIDs;
	public TreeMap<Integer, NodeFile> nodes;
	public int time;


	public Network(String networkFilename) throws Exception {
		nodes = new TreeMap<Integer, NodeFile>();
		time = 0;
		
		loadFromFile(networkFilename);
	}
	
	//keep on recomputing the nodes for the routing table
	public void recomputeRouting() {
		for(int nodeID : nodes.keySet()) {
			NodeFile currentNode = nodes.get(nodeID);
			if(currentNode.isItUnsent) {

				for(int neighbouringID : currentNode.distVectTable.keySet()) {
					if(neighbouringID != nodeID) {
						nodes.get(neighbouringID).receiveMessage(nodeID, currentNode.distVectTable.get(nodeID)); //send node's own row in table to others
					}
				}
				
				currentNode.isItUnsent = false;
			}
		}
		
		for(int nodeID : nodes.keySet()) {
			if(nodes.get(nodeID).rcvdMsgNew) {
				nodes.get(nodeID).computeTable();
			}
		}
		time++;
	}
	//keep on calling the recomputing function if the network is not stable in order to have steady state
	public void beStable() {
		while(!networkStability()) {
			recomputeRouting();
		}
	}
	//checks to see if no new messages were sent to node, this means system is in steady state
	public boolean networkStability() {
		for(int nodeID : nodes.keySet()) {
			if(nodes.get(nodeID).isItUnsent) {
				return false;
			}
		}
		
		return true; 
	}
	
	//changes the cost of the link
	public void changeLink(int nodeone, int nodetwo, int cost) {
		nodes.get(nodeone).setLink(nodetwo, cost);
		nodes.get(nodetwo).setLink(nodeone, cost);
	}
	
	//to display the table
	public String toString() {
		String result = "";
		result += "\t Current time: " + time + "\n\n";
		result += "______________________________\n\n";
		for(int nodeID : nodes.keySet()) {
			result += nodes.get(nodeID).toString() + "\n";
			result += "______________________________\n\n";
		}
		
		return result;
	}

	private void loadFromFile(String filename) throws Exception {
		try {
			nodeIDs = this.getIDsFromFile(filename);
			for(int id : nodeIDs) {
				nodes.put(id, new NodeFile(id, nodeIDs));
			}
			
			BufferedReader input = new BufferedReader(new FileReader(filename));
				
			String line = null;
			while((line = input.readLine()) != null) { 
				String[] data = line.split(" ");
				int sourceID = Integer.parseInt(data[0]);
				int destID = Integer.parseInt(data[1]);
				int distance = Integer.parseInt(data[2]);
				
				nodes.get(sourceID).addNeighbor(destID, distance, nodeIDs);
				nodes.get(destID).addNeighbor(sourceID, distance, nodeIDs);
			}
			
			
			input.close();
		} catch(Exception e) {
			throw new Exception("Unable to find and load " + filename);
		}
	}
	
	//reads the IDs of nodes
	private TreeSet<Integer> getIDsFromFile(String filename) throws Exception {
		TreeSet<Integer> ids = new TreeSet<Integer>();
		
		BufferedReader input = new BufferedReader(new FileReader(filename));
				
		String line = null;
		while((line = input.readLine()) != null) { 
			String[] data = line.split(" ");
			int sourceID = Integer.parseInt(data[0]);
			int destID = Integer.parseInt(data[1]);
			if(!ids.contains(sourceID)) {
				ids.add(sourceID);
			}
			
			if(!ids.contains(destID)) {
				ids.add(destID);
			}
		}
		
		input.close();
		
		return ids;
	}
}
